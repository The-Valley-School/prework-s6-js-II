/* 
  A) Crear un objeto cancion con las propiedades titulo, cantante, duracion(en segundos) y genero. 
  Metiendo los datos que queramos.
  Ejemplo: Zapatillas, El canto del loco, 180, pop
  B) Utilizando un swicth con el género, sacar por consola si me gusta o no este tipo 
  de música.
  Generos que debe contemplar el switch: pop, rock, trap, punk
  Si el tipo de canción es rock o trap, el mensaje será "Me gusta la canción XXX (titulo de la canción objeto)"
  Si el tipo de canción es trap o punk, el mensaje será "No me gusta XXX (cantante del objeto canción)"
  Si el género es diferente a esto, el mensaje será "No he escuchado este género"
*/

let cancion = {
    titulo: "Zapatillas",
    cantante: "El canto del loco",
    duracion: 180,
    genero: "pop"
}

switch(cancion.genero){
    case "pop":
        console.log("No me gusta " + cancion.cantante);
        break;
    case "rock":
        console.log("Me gusta la canción " + cancion.titulo);
        break;
    case "trap":
        console.log("Me gusta la canción " + cancion.titulo);
        break;
    case "punk":
        console.log("No me gusta " + cancion.cantante);
        break;
    default:
        console.log("No he escuchado este género");
        break;
}