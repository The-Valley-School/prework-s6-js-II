/*
  Teniendo el siguiente array: 
  [3, 7, 20, 12, 100, 50, 5, 2, 40]
  
  Usando un bucle genera un array que indique **true** si el número del array
  es mayor que 10 y **false** si es menor o igual
  
  La solución sería el siguiente array :
  [false, false, true, true, true, true, false, false, true]
*/

let peliculas = [3, 7, 20, 12, 100, 50, 5, 2, 40];
let mayor10 = [];

for (let i = 0; i < peliculas.length; i++){
   if ( peliculas[i] > 10 ){
        mayor10[i] = true;
   } else {
        mayor10[i] = false;
   }

}
console.log(mayor10);