/*
  A) Crea un array con 5 películas que te gusten
  B) Muestra esas 5 películas por consola, usando un bucle for. 
    Las películas tienen que mostrarse de la última posición a la primera.

  Ejemplo de array -> ["E.T.", "Toy Story", "Bichos", "Nemo", "Dori"]
  Resultado por consola:
    Dori
    Nemo
    Bichos
    Toy Story
    E.T.
*/

let peliculas = ["E.T.", "Toy Story", "Bichos", "Nemo", "Dori"];

for (let i = (peliculas.length - 1); i >= 0; i--){
    console.log(peliculas[i]);
}