/*
  A) Crea una variable con la suma todos los números impares del 300 al 400
  B) Crea un array con todos los números pares, utilizando el bucle 
  del apartado A 
*/

let sumador = 0;
let numerosPares = [];

for (let i = 300; i <= 400; i++){
    if ( i % 2 === 1){
        sumador += i;
    } else {
        numerosPares.push(i);
    }
}

console.log(sumador);
console.log(numerosPares);